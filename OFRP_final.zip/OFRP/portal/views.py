from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse
from .form import recp, feed
from .models import Category, Recipe, Feedback
from django.urls import reverse


def index(request):
    return render(request, 'portal/index.html')


def show(request):
    if request.method=='GET': #land without form
        recipe=Recipe.objects.all().order_by('recipe_name')
    else: #lands with search form in nav bar
        recipe=Recipe.objects.filter(recipe_name__startswith=request.POST['text'])
    return render(request, 'portal/admin/show.html', {'recipe': recipe} )


def add(request, id=0):
    if request.method=='GET':
        if id==0:
            form=recp()
            return render(request, 'portal/admin/addRecipe.html', {'form': form})
        else: #from update link
            recipe=Recipe.objects.get(pk=id)
            form=recp(instance=recipe)
            return render(request, 'portal/admin/addRecipe.html', {'form': form})
    else: #when method==POST
        if id==0:
            form=recp(request.POST, request.FILES)
            if form.is_valid:
                form.save()
            return redirect('show/')        
        else:     
            recipe=Recipe.objects.get(pk=id)
            form=recp(request.POST, instance=recipe)
            if form.is_valid:
                form.save()
            return redirect('../show')        

def delete(request, id):
    recipe=Recipe.objects.get(pk=id)
    recipe.delete()
    return redirect('../../show')

def showCategory(request):
    category= Category.objects.all()
    context={'category':category}
    
    if request.method=='POST':
        recipe=Recipe.objects.filter(category_id=request.POST['category'])
        context={'recipe':recipe,'category':category}
        return render(request, 'portal/admin/showCategory.html',context)

    return render(request, 'portal/admin/showCategory.html',context)

def show_feedback(request, recipe_id):
    recipe = get_object_or_404(Recipe, pk=recipe_id)
    return render(request, 'portal/admin/showFeedback.html', {'recipe': recipe })

def delete_feedback(request, feed_id):
    feed=Feedback.objects.get(pk=feed_id)
    feed.delete()
    return redirect('../../show')

def ShowRecipes(request):
    if request.method=='GET': #land without form
        recipe=Recipe.objects.all().order_by('recipe_name')
    else: #lands with search form in nav bar
        recipe=Recipe.objects.filter(recipe_name__startswith=request.POST['text'])
    return render(request, 'portal/user/home.html', {'recipe': recipe} )


def about(request):
    return render(request, 'portal/user/about.html')


def viewRecipe(request, recipe_id):
    recipe = get_object_or_404(Recipe, pk=recipe_id)

    if request.method=='POST': #when method==POST
        form=feed(request.POST)
        if form.is_valid:
            form.save()
        return render(request, 'portal/user/viewRecipe.html', {'recipe': recipe , 'form': form})
    form=feed() 
    recipe = get_object_or_404(Recipe, pk=recipe_id)
    return render(request, 'portal/user/viewRecipe.html', {'recipe': recipe , 'form': form})


# def Category(request):
#     category= Category.objects.all()
#     context={'category':category}
    
#     if request.method=='POST':
#         recipe=Recipe.objects.filter(category_id=request.POST['category'])
#         context={'recipe':recipe,'category':category}
#         return render(request, 'portal/user/category.html',context)

#     return render(request, 'portal/user/category.html',context)
