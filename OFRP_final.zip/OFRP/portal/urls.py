from django.urls import path

from . import views

appname='portal'
urlpatterns = [
    path('', views.index, name='index'),
    path('show/', views.show, name='show_recipe'),
    path('addRecipe', views.add, name='addRecipe'),
    path('<int:id>/', views.add, name='recp_update'),
    path('delete/<int:id>/', views.delete, name='recp_delete'),
    path('showCategory', views.showCategory, name='showCategory'),
    path('showfeedback/<int:recipe_id>/', views.show_feedback, name='show_feedback'),
    path('feedback/<int:feed_id>/', views.delete_feedback, name='delete_feedback'),
    path('home/', views.ShowRecipes, name='ShowRecipes'),
    path('about/', views.about, name='About'),
    path('viewRecipe/<int:recipe_id>/', views.viewRecipe, name='viewRecipe'),

    # path('Category/', views.Category, name='Category'),



]