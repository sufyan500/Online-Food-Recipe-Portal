from django import forms
from .models import Recipe, Feedback

class recp(forms.ModelForm):
    class Meta:
        model=Recipe 
        fields=('recipe_name', 'category_id','recipe_cooktime','recipe_ingredients', 'recipe_desc','recipe_chef','recipe_publish_datetime','recipe_image')
        labels={
            'recipe_name': 'Recipe', 
            'category_id': 'Category',
            'recipe_cooktime': 'Est.Time',
            'recipe_ingredients': 'Ingredients', 
            'recipe_desc': 'Process',
            'recipe_chef': 'Cheff',
            'recipe_publish_datetime': 'Post Date'
        }
        
class feed(forms.ModelForm):
    class Meta:
        model=Feedback 
        fields=('name', 'recipe', 'rating','comment','feedback_publish_datetime')
        labels={
            'name': 'Name', 
            'recipe':'Recipe', 
            'rating':'Rating(1-5)',
            'comment':'Comment',
            'feedback_publish_datetime':'Feedback DateTime'
        }