from django.utils import timezone

from django.db import models



class Category(models.Model):
    category_title=models.CharField(max_length=50)
    
    def __str__(self):
        return self.category_title
    
    
class Recipe(models.Model):
    recipe_chef=models.CharField(max_length=50, default="")
    recipe_name=models.CharField(max_length=50)
    recipe_ingredients=models.CharField(max_length=200)
    recipe_desc=models.TextField(max_length=700)
    recipe_publish_datetime=models.DateTimeField(default=timezone.now)
    recipe_cooktime=models.CharField(max_length=50)
    recipe_image=models.ImageField(null=True, blank=True, upload_to="images/" )
    category_id=models.ForeignKey(Category, on_delete=models.CASCADE)

    def __str__(self):
        return '{} '.format(self.recipe_name)
    
class Feedback(models.Model):
    name=models.CharField(max_length=50)
    rating=models.IntegerField(default=0)
    comment=models.TextField(max_length=700)
    feedback_publish_datetime=models.DateTimeField(default=timezone.now)
    recipe=models.ForeignKey(Recipe, on_delete=models.CASCADE)
    
    def __str__(self):
        return self.name

    